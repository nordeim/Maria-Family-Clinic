(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__da0a2e98._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/src/server/auth.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "auth",
    ()=>auth,
    "authConfig",
    ()=>authConfig,
    "getServerAuthSession",
    ()=>getServerAuthSession,
    "handlers",
    ()=>handlers,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@auth/prisma-adapter/index.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$2f$default$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@prisma/client/default.js [middleware-edge] (ecmascript)");
;
;
;
// Providers
const providers = [
    {
        id: 'google',
        name: 'Google',
        type: 'oauth',
        wellKnown: 'https://accounts.google.com/.well-known/openid-configuration',
        clientId: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        checks: [
            'pkce',
            'state'
        ],
        profile (profile) {
            return {
                id: profile.sub,
                name: profile.name,
                email: profile.email,
                image: profile.picture
            };
        }
    },
    // Email provider for authentication without external services
    {
        id: 'email',
        name: 'Email',
        type: 'email',
        maxAge: 24 * 60 * 60,
        async sendVerificationRequest ({ identifier, url, token }) {
            // For development - just log the verification URL
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('🔐 Email verification URL:', url);
                return;
            }
        // In production, implement proper email sending
        // Example with Resend, SendGrid, etc.
        // await resend.emails.send({
        //   from: 'noreply@your-domain.com',
        //   to: identifier,
        //   subject: 'Verify your email address',
        //   html: `Click <a href="${url}">here</a> to verify your email address.`,
        // })
        }
    }
];
const authConfig = {
    debug: ("TURBOPACK compile-time value", "development") === 'development',
    adapter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["PrismaAdapter"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$prisma$2f$client$2f$default$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["PrismaClient"]()),
    providers,
    session: {
        strategy: 'jwt',
        maxAge: 30 * 24 * 60 * 60
    },
    cookies: {
        sessionToken: {
            name: 'my-family-clinic-session',
            options: {
                httpOnly: true,
                sameSite: 'lax',
                path: '/',
                secure: ("TURBOPACK compile-time value", "development") === 'production'
            }
        }
    },
    callbacks: {
        async signIn ({ user, account, profile }) {
            // Additional sign-in validation
            if (user.email) {
                // Check if email is from allowed domains (for healthcare context)
                const allowedDomains = [
                    'gmail.com',
                    'yahoo.com',
                    'hotmail.com',
                    'outlook.com',
                    'singhealth.com.sg',
                    'nhg.com.sg',
                    'nuhs.edu.sg'
                ];
                const domain = user.email.split('@')[1];
                if (!allowedDomains.includes(domain)) {
                    console.warn(`Email domain ${domain} not in allowed list`);
                // Allow sign-in but log for review
                }
            }
            return true;
        },
        async jwt ({ token, user }) {
            // Add custom claims to JWT token
            if (user) {
                token.userId = user.id;
                token.email = user.email;
                token.name = user.name;
            }
            return token;
        },
        async session ({ session, token }) {
            // Add user info to session
            if (session.user) {
                session.user.id = token.userId;
                session.user.email = token.email;
                session.user.name = token.name;
            }
            return session;
        }
    },
    events: {
        async signIn ({ user, account }) {
            // Log successful sign-ins
            console.log(`✅ User signed in: ${user.email} via ${account?.provider}`);
        // You could also log to database for audit purposes
        // await logAuditEvent({
        //   action: 'user_signed_in',
        //   userId: user.id,
        //   metadata: { provider: account?.provider },
        // })
        },
        async signOut ({ session, token }) {
            // Log sign-outs
            console.log(`🚪 User signed out: ${token?.email}`);
        },
        async createUser ({ user }) {
            // Log new user creation
            console.log(`👤 New user created: ${user.email}`);
        // You could send welcome email, create user profile, etc.
        }
    },
    pages: {
        signIn: '/auth/signin',
        signOut: '/auth/signout',
        error: '/auth/error',
        verifyRequest: '/auth/verify',
        newUser: '/auth/welcome'
    }
};
const { handlers, auth, signIn, signOut } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(authConfig);
const getServerAuthSession = async ()=>{
    return await auth();
};
}),
"[project]/src/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "middleware",
    ()=>middleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$server$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/server/auth.ts [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
;
;
async function middleware(request) {
    // Get the pathname
    const pathname = request.nextUrl.pathname;
    // Public routes that don't require authentication
    const publicRoutes = [
        '/',
        '/clinics',
        '/services',
        '/doctors',
        '/healthier-sg',
        '/contact',
        '/auth',
        '/api/auth',
        '/_next',
        '/favicon.ico'
    ];
    // Check if the route is public
    const isPublicRoute = publicRoutes.some((route)=>pathname === route || pathname.startsWith(route));
    // Get the session
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$server$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["auth"])();
    // If it's a protected route and user is not authenticated
    if (!isPublicRoute && !session) {
        const signInUrl = new URL('/auth/signin', request.url);
        signInUrl.searchParams.set('callbackUrl', pathname);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(signInUrl);
    }
    // If user is authenticated and tries to access auth pages, redirect to home
    if (session && pathname.startsWith('/auth')) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/', request.url));
    }
    // Role-based access control for admin routes
    if (pathname.startsWith('/admin')) {
        if (!session || session.user?.role !== 'admin') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/', request.url));
        }
    }
    // Healthcare provider access control
    if (pathname.startsWith('/provider')) {
        if (!session || ![
            'admin',
            'provider',
            'clinic_admin'
        ].includes(session.user?.role || '')) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/', request.url));
        }
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
}
const config = {
    matcher: [
        /*
     * Match all request paths except for the ones starting with:
     * - api/auth (NextAuth.js routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public assets (images, etc.)
     */ '/((?!api/auth|_next/static|_next/image|favicon.ico|public).*)'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__da0a2e98._.js.map