var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/trpc/[trpc]/route.js")
R.c("server/chunks/[root-of-the-server]__9ab00207._.js")
R.c("server/chunks/[root-of-the-server]__7f35642a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_aa22b09c.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_trpc_[trpc]_route_actions_646e8836.js")
R.m(73972)
module.exports=R.m(73972).exports
