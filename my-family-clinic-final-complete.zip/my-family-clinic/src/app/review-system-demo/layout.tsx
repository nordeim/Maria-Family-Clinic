export default function ReviewSystemDemoLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
