// Add scroll-area to the UI component exports
export { ScrollArea, ScrollBar } from "./scroll-area"