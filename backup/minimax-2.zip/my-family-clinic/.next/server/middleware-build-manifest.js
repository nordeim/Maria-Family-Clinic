globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/664adc71bc2617c2.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c03e62c4a1814acc.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/4d8157714a724382.js",
    "static/chunks/73a330e38f4c895c.js",
    "static/chunks/96dbdc0078c3e232.js",
    "static/chunks/turbopack-316f5807eb7dd812.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];