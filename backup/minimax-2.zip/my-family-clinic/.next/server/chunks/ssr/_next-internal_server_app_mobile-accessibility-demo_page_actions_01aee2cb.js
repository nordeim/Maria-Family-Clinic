module.exports=[23315,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mobile-accessibility-demo_page_actions_01aee2cb.js.map