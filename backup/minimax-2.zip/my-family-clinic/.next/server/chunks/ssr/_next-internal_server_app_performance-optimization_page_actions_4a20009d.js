module.exports=[47389,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_performance-optimization_page_actions_4a20009d.js.map