module.exports=[4082,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_clinics_page_actions_2745027e.js.map